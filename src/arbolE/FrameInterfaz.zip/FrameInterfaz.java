/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package arbolE;

import java.awt.Image;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import static javax.swing.JOptionPane.showMessageDialog;

/**
 *
 * @author sophi
 */
public class FrameInterfaz extends javax.swing.JFrame {

    /**
     * Creates new form FrameInterfaz
     */
    FrameColorNodos arbolColor;
     public String datos ;
    String nPolaca;
    // 10 de julio
    int temp;
    
    // 15 de julio
    String Izquierdo,derecho;
    String emulocal = "\n";
    int Contador = 0;

    // 10 de Julio - integracion de las clases nuevas del equipo
    FrameCuadruplos cuadruplos;
    FrameTripletas frameTripletas;
    // Ultimo arbol construido 
    private Nodo arbolActual;

    public FrameInterfaz() {
        initComponents();

        arbolColor = new FrameColorNodos();

        Izquierdo = derecho =  "";

       
       


        java.net.URL url2 = getClass().getResource("/arbolE/yo.jpeg"); 
        ImageIcon icon2 = new ImageIcon(url2);
        Image imagenEscalada2 = icon2.getImage().getScaledInstance(
                100,
                100,
                Image.SCALE_AREA_AVERAGING
        ); 
        
        yo.setIcon(new ImageIcon(imagenEscalada2));
        
        java.net.URL url3 = getClass().getResource("/arbolE/logo.jpeg"); 
        ImageIcon icon3 = new ImageIcon(url3);
        Image imagenEscalada3 = icon3.getImage().getScaledInstance(
                100,
                100,
                Image.SCALE_AREA_AVERAGING
        ); 
        
        pato.setIcon(new ImageIcon(imagenEscalada3));
    }

    
    public void generaEmutasm(String emu, int i){
        try{
            String nombreArchivo = "e" + i + ".asm";
            FileWriter escritor = new FileWriter(nombreArchivo);
            escritor.write(emu);
            escritor.close();
            System.out.println("Archivo creado exitosamente");
            
            File archivo = new File(nombreArchivo);
            String rutaEmu8086 = "C:\\emu8086\\emu8086.exe"; 

            String rutaAbsoluta = archivo.getAbsolutePath();

            Runtime.getRuntime().exec(new String[]{rutaEmu8086, rutaAbsoluta});
        }
        catch(Exception e){
            System.out.println("Ha ocurrido un error al crear el archivo");
        }
    }
    
    public void sonido(){
  
    try {
        File sonido = new File ("/Users/sophiazapete/Verano 2026/Automatas II/Proyecto Arbol/ArbolExpresiones/src/arbolE/new-notification-022-370046.wav");
        if (sonido.exists()) {
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(sonido);
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);
            clip.start(); 
        } else {
            showMessageDialog(null, "No se encontró el archivo de sonido.");
        }
    } catch (Exception e) {
        e.printStackTrace();
        showMessageDialog(null, "Error al reproducir el sonido.");
    }
    }//sonido
    
    
    
    
    
    
    
    public String cadena(String datos){
        datos = jTextField1.getText();
        return datos;
    }
    
    public void inOrden(Nodo n){
       if(n!=null){
           inOrden(n.getIzquierdo());
           jTxtInOrden.append(n.getDato()+"\n");
           
           inOrden(n.getDerecho());
           
           
           //15 julio
           
            
            switch (n.getDato()) {
                case "+": System.out.println("ADD Gonzalez Zapete Sophia");
                Izquierdo = n.getIzquierdo().getDato();
                derecho = n.getDerecho().getDato();
                
                    System.out.println("izq: "+Izquierdo);
                    System.out.println("der: "+derecho);
                    emulocal +=  "mov ax "+ n.getIzquierdo().getDato();
                    emulocal +=  "mov bx "+ n.getDerecho().getDato();
                
                break;
                
                
                case "-": System.out.println("sub");
                Izquierdo = n.getIzquierdo().getDato();
                derecho = n.getDerecho().getDato();
                break;
                
                case "/": System.out.println("div");
                Izquierdo = n.getIzquierdo().getDato();
                derecho = n.getDerecho().getDato();
                break;
                
                case "*": System.out.println("mul"); 
                Izquierdo = n.getIzquierdo().getDato();
                derecho = n.getDerecho().getDato();
                break;
            }// fin switch
       }  
    
    }
    
    
    public void postOrden(Nodo n){
        if(n!=null){
          postOrden(n.getIzquierdo());
           postOrden(n.getDerecho());
           jtxtPostOrden.append(n.getDato()+"\n");
           
           
           
       } 
    
    }
    
    
    public void intermedio(Nodo n){
      if(n!=null){
         
          intermedio(n.getIzquierdo());
          intermedio(n.getDerecho());
          
         if(n.getDerecho()==null && n.getIzquierdo()==null ) {
             n.setLugar(n.getDato()+ " ");
             n.setCodigoIntermedio(""); //aqui
             
         
         }else{
             if(n.getDato().equals("+") || n.getDato().equals("*") || n.getDato().equals("-") || n.getDato().equals("/") ) {
             temp++;
              n.setLugar("T"+temp);
              Nodo izquierdo = n.getIzquierdo();
              Nodo derecho = n.getDerecho();
              String codigoI = "";
              codigoI = izquierdo.getCodigoIntermedio()+" "+derecho.getCodigoIntermedio()+" "+n.getLugar()+" = "+izquierdo.getLugar()
                      + " "+n.getDato()+ " "+ derecho.getLugar();
              n.setCodigoIntermedio(codigoI+"\n");
                 
             }else{
                    if(n.getDato().equals("=")){
                      String codigoI = "";
                      Nodo izquierdo = n.getIzquierdo();
                      Nodo derecho = n.getDerecho();
                      codigoI = derecho.getDato() + " "+ izquierdo.getLugar()+ " "+temp+"\n";
                      n.setCodigoIntermedio(codigoI);
                    }// equal =
             }// equal + - * /
         
         }// get derecho
          
      }  // n! null
    
    }// intermedio 
    
    
    public void preOrden(Nodo n){
        if(n!=null){

            jtxtPreorden.append(n.getDato()+"\n");
            nPolaca += jNotacionPolaca.getText()+ n.getDato() + " ";
            jNotacionPolaca.setText(jNotacionPolaca.getText()+n.getDato()+" ");
            preOrden(n.getIzquierdo());
            preOrden(n.getDerecho());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        yo = new javax.swing.JLabel();
        pato = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jNotacionPolaca = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtxtPreorden = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTxtInOrden = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        jtxtPostOrden = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextArea5 = new javax.swing.JTextArea();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Arbol de expresiones - LyA2");

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/arbolE/peque.png"))); // NOI18N
        jLabel10.setText("jLabel10");

        yo.setText("jLabel11");

        pato.setIcon(new javax.swing.ImageIcon(getClass().getResource("/arbolE/logo.jpeg"))); // NOI18N
        pato.setText("jLabel9");
        pato.setPreferredSize(new java.awt.Dimension(100, 100));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(yo, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(yo, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Notacio Polaca");

        jButton2.setText("Codigo 3 direcciones");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Cuádruplos");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Tabla de Simbolos");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addComponent(jNotacionPolaca, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addComponent(jButton2)
                .addGap(41, 41, 41)
                .addComponent(jButton3)
                .addGap(34, 34, 34)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jNotacionPolaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4))
                .addGap(13, 13, 13))
        );

        jPanel4.setBackground(new java.awt.Color(255, 204, 102));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Pre Orden");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("In Orden");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Post Orden");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Reglas Semanticas");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("Codigo 3 direcciones");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jTextField1.setBackground(new java.awt.Color(255, 255, 153));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jButton1.setText("Compila");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jtxtPreorden.setColumns(20);
        jtxtPreorden.setRows(5);
        jScrollPane2.setViewportView(jtxtPreorden);

        jTxtInOrden.setColumns(20);
        jTxtInOrden.setRows(5);
        jScrollPane3.setViewportView(jTxtInOrden);

        jtxtPostOrden.setColumns(20);
        jtxtPostOrden.setRows(5);
        jScrollPane4.setViewportView(jtxtPostOrden);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Expresiones");

        jTextArea5.setColumns(20);
        jTextArea5.setRows(5);
        jScrollPane5.setViewportView(jTextArea5);

        jButton5.setText("Agente IA");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jLabel3)
                        .addGap(31, 31, 31)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 453, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)
                        .addGap(32, 32, 32)
                        .addComponent(jButton5)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1)
                    .addComponent(jLabel3)
                    .addComponent(jButton5))
                .addGap(18, 27, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 315, Short.MAX_VALUE)
                    .addComponent(jScrollPane4))
                .addGap(41, 41, 41))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel2)
                .addGap(56, 56, 56)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(39, 39, 39)
                .addComponent(jLabel6)
                .addGap(32, 32, 32)
                .addComponent(jLabel7)
                .addGap(23, 23, 23))
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         String datos = "";
    // temp = 0;
    //Arbol a = new Arbol();
    //ArbolSophia arbolsophia = new ArbolSophia();
    
    ArbolIa arbol = new ArbolIa();
    datos = jTextField1.getText();
    Nodo arbolExpresion = arbol.crear(datos);
    
     jTextArea1.append(arbol.getReglasEjecutadas());
    //Nodo arbolExpresion = arbolsophia.crear(datos);
    //jTextArea1.append(arbolsophia.getReglasEjecutadas());
        
        preOrden(arbolExpresion);
        inOrden(arbolExpresion);
        postOrden(arbolExpresion);
        intermedio(arbolExpresion);

        // 10 de Julio - se guarda el ultimo arbol compilado (ya con su
        // codigo intermedio calculado por intermedio()) para que otros
        // botones como "Cuadruplos" lo puedan usar.
        arbolActual = arbolExpresion;

        //String text=" ";
        //text = arbol.getReglasEjecutadas();
        jTextArea5.append(arbolExpresion.getCodigoIntermedio());
        try {
            PrintWriter out = new PrintWriter("Reglas_Semanticas.txt");
         
            out.println(arbol.getReglasEjecutadas());
            out.close();

        } catch (FileNotFoundException ex) {
            Logger.getLogger(FrameInterfaz.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:

        String datos = jTextField1.getText();

        ArbolIa arbol = new ArbolIa();
        Nodo arbolExpresion = arbol.crear(datos);

        jTextArea1.append(arbol.getReglasEjecutadas());
        
        // Pide por consola (System.in) el valor de cada identificador (id)
        // en las hojas del arbol y evalua los operadores de la pila de
        // caracteres (+,-,*,/,^) con esos valores. Esta es la UNICA vez que
        // se pregunta: el arbol ya evaluado se le pasa a FrameColorNodos.
        arbol.evaluar(arbolExpresion);

        // Muestra en el output (consola) las reglas ejecutadas y la tabla de simbolos
        System.out.println(arbol.getReglasEjecutadas());
        arbol.mostrarTablaSimbolos();

        preOrden(arbolExpresion);

        // 10 de Julio - se guarda el ultimo arbol construido 
        arbolActual = arbolExpresion;
        frameTripletas = new FrameTripletas(arbol.getTripletas());
        frameTripletas.setVisible(true);

        // Envia el arbol ya construido y evaluado a la ventana de color/ancho
        // del AST antes de mostrarla .
        arbolColor.setDatos(datos);
        arbolColor.setArbol(arbolExpresion);
        arbolColor.setVisible(true);
        
        preOrden(arbolExpresion);
        inOrden(arbolExpresion);
        postOrden(arbolExpresion);
        intermedio(arbolExpresion);
        // 15 de julio
        // creamos la variabe emu la cual guarda el texto en ensamblador de la suma
        // 
        arbol.emu8086+=".CODE \n"+"MOV AX,@DATA \n"+"MOV DS,AX\n";
        String finalEmu =  arbol.emu8086 + this.emulocal;
        finalEmu += "\n MOV AX,4C00H \n "+"INT 21H \n END";
        showMessageDialog(null,finalEmu);
        Contador ++;
        generaEmutasm(finalEmu,Contador);
        sonido();
        
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:]
        FrameDescripcion ventanaIntermedio = new FrameDescripcion();
            ventanaIntermedio.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        if (arbolActual == null) {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Primero presiona 'Compila' con una expresion.",
                        "Falta expresion", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            cuadruplos = new FrameCuadruplos(arbolActual);
            cuadruplos.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrameInterfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrameInterfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrameInterfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrameInterfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //new FrameInterfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField jNotacionPolaca;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea5;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextArea jTxtInOrden;
    private javax.swing.JTextArea jtxtPostOrden;
    private javax.swing.JTextArea jtxtPreorden;
    private javax.swing.JLabel pato;
    private javax.swing.JLabel yo;
    // End of variables declaration//GEN-END:variables
}
